import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

/*
2020 Calculator for Programming 1
Annika Damstedt | Nov 2020
*/

//global values
Button[] numButtons = new Button[10];
Button[] opButtons = new Button[13];
String dVal;
String op;
float r =0.0f;
float l = 0.0f;
float result = 0.0f;
boolean left;
boolean noNum;

//declare variables and declare buttons
public void setup() {
  
  dVal = "0";
  op = "";
  left = true;
  r = 0.0f;
  l = 0.0f;
  result = 0.0f;

  numButtons[0] = new Button(100, 160, 60, 60, "0", true, 0xff00CBBC, 0xff03A089);
  numButtons[1] = new Button(20, 240, 60, 60, "1", true, 0xff00CBBC, 0xff03A089);
  numButtons[2] = new Button(100, 240, 60, 60, "2", true, 0xff00CBBC, 0xff03A089);
  numButtons[3] = new Button(180, 240, 60, 60, "3", true, 0xff00CBBC, 0xff03A089);
  numButtons[4] = new Button(20, 320, 60, 60, "4", true, 0xff00CBBC, 0xff03A089);
  numButtons[5] = new Button(100, 320, 60, 60, "5", true, 0xff00CBBC, 0xff03A089);
  numButtons[6] = new Button(180, 320, 60, 60, "6", true, 0xff00CBBC, 0xff03A089);
  numButtons[7] = new Button(20, 400, 60, 60, "7", true, 0xff00CBBC, 0xff03A089);
  numButtons[8] = new Button(100, 400, 60, 60, "8", true,0xff00CBBC, 0xff03A089);
  numButtons[9] = new Button(180, 400, 60, 60, "9", true, 0xff00CBBC, 0xff03A089);

  opButtons[0] = new Button(20, 160, 60, 60, "+/-", false, 0xff00B1CE, 0xff028BA2);
  opButtons[1] = new Button(180, 160, 60, 60, "x²", false, 0xff00B1CE, 0xff028BA2);
  opButtons[2] = new Button(260, 160, 60, 60, "√", false, 0xff00B1CE, 0xff028BA2);
  opButtons[3] = new Button(340, 160, 60, 60, "+", false, 0xff00B1CE, 0xff028BA2);
  opButtons[4] = new Button(260, 240, 60, 60, "sin", false, 0xff00B1CE, 0xff028BA2);
  opButtons[5] = new Button(340, 240, 60, 60, "-", false, 0xff00B1CE, 0xff028BA2);
  opButtons[6] = new Button(260, 320, 60, 60, "cos", false, 0xff00B1CE, 0xff028BA2);
  opButtons[7] = new Button(340, 320, 60, 60, "x", false, 0xff00B1CE, 0xff028BA2);
  opButtons[8] = new Button(260, 400, 60, 60, "Rand", false, 0xff00B1CE, 0xff028BA2);
  opButtons[9] = new Button(340, 400, 60, 60, "/", false, 0xff00B1CE, 0xff028BA2);
  opButtons[10] = new Button(20, 480, 140, 60, "C", false, 0xff86C8D3, 0xff77B4BF);
  opButtons[11] = new Button(260, 480, 140, 60, "=", false, 0xff86C8D3, 0xff77B4BF);
  opButtons[12] = new Button (180, 480, 60, 60, ".", false, 0xff00B1CE, 0xff028BA2);
}

//call updateDisplay and buttons
public void draw() {
  background (0);

  updateDisplay();

  for (int i=0; i<numButtons.length; i++) {
    numButtons[i].display();
    numButtons[i].hover();
  }
  for (int i=0; i<opButtons.length; i++) {
    opButtons[i].display();
    opButtons[i].hover();
  }
}

//create display and shrink text based on amount
public void updateDisplay() {
  rectMode (CORNER);
  fill (0xffC5E3E8);
  rect (20, 20, 380, 120, 10);

  //shading
  strokeWeight (4);
  stroke (0, 100);
  line (22, 138, 398, 138);
  line (398, 138, 398, 22);
  stroke (255, 100);
  line (22, 138, 22, 22);
  line (22, 22, 398, 22);

  textAlign (RIGHT);
  fill (0);

  if (dVal.length()<13) {
    textSize(38);
  } else if (dVal.length()<17) {
    textSize(34);
  } else if (dVal.length()<18) {
    textSize(32);
  } else if (dVal.length()<20) {
    textSize(30);
  } else if (dVal.length()<22) {
    textSize(28);
  } else if (dVal.length()<25) {
    textSize(26);
  } else if (dVal.length()<27) {
    textSize(24);
  } else if (dVal.length()<30) {
    textSize(22);
  } else {
    textSize(20);
  }
  text (dVal, width-30, 120);
}

//determine which buttons pressed
public void mousePressed() {
  for (int i=0; i<numButtons.length; i++) {
    if (numButtons[i].hover && dVal.length()<20) {
      handleEvent (numButtons[i].val, true);
    }
  }
  for (int i=0; i<opButtons.length; i++) {
    if (opButtons[i].hover) {
      handleEvent (opButtons[i].val, false);
    }
  }
}

//determine which keys clicked
public void keyPressed() {
  if (key == '0') {
    handleEvent ("0", true);
  } else if (key == '1') {
    handleEvent ("1", true);
  } else if (key == '2') {
    handleEvent ("2", true);
  } else if (key == '3') {
    handleEvent ("3", true);
  } else if (key == '4') {
    handleEvent ("4", true);
  } else if (key == '5') {
    handleEvent ("5", true);
  } else if (key == '6') {
    handleEvent ("6", true);
  } else if (key == '7') {
    handleEvent ("7", true);
  } else if (key == '8') {
    handleEvent ("8", true);
  } else if (key == '9') {
    handleEvent ("9", true);
  } else if (key == '+') {
    handleEvent ("+", false);
  } else if (key == '-') {
    handleEvent ("-", false);
  } else if (key == '*') {
    handleEvent ("x", false);
  } else if (key == '/') {
    handleEvent ("/", false);
  } else if (key == '.') {
    handleEvent (".", false);
  } else if (key == 27 || key == 'C' || key == 'c') {
    handleEvent ("C", false);
  } else if (key == 10) {
    if (keyCode == ENTER || keyCode == RETURN) {
      handleEvent ("=", false);
    }
  }
}

//show result of buttons clicked or pressed
public String handleEvent (String val, boolean num) {
  if (left && num && !noNum) {
    if (dVal.equals("0") || result == l) {
      dVal = (val);
      l = PApplet.parseFloat (dVal);
    } else {
      dVal += (val);
      l = PApplet.parseFloat (dVal);
    }
  } else if (!left && num && !noNum) {
    if (dVal.equals("0") || dVal.equals(op) || result == l) {
      dVal = (val);
      r = PApplet.parseFloat (dVal);
    } else {
      dVal += (val);
      r = PApplet.parseFloat (dVal);
    }
  } else if (val.equals("C")) {
    dVal = "0";
    result = 0.0f;
    left = true;
    r = 0.0f;
    l = 0.0f;
    op = "";
    noNum = false;
  } else if (val.equals("+")) {
      op = "+";
      left = false;
      dVal = "+";
      noNum = false;
  } else if (val.equals("-")) {
      op = "-";
      left = false;
      dVal = "-";
      noNum = false;
  } else if (val.equals("x")) {
      op = "x";
      left = false;
      dVal = "x";
      noNum = false;
  } else if (val.equals("/")) {
      op = "/";
      left = false;
      dVal = "/";
      noNum = false;
  } else if (val.equals("Rand")) {
    if (left) {
      l = random (0, 1);
      dVal = str(l);
      noNum = true;
    } else {
      r = random (0, 1);
      dVal = str(r);
      noNum = true;
    }
  } else if (val.equals("+/-")) {
    if (left) {
      l *= -1;
      dVal = str(l);
    } else {
      r *= -1;
      dVal = str(r);
    }
  } else if (val.equals("x²")) {
    if (left) {
      l = sq(l);
      dVal = str(l);
      noNum = true;
    } else {
      r = sq(r);
      dVal = str(r);
      noNum = true;
    }
  } else if (val.equals("√")) {
    if (left) {
      l = sqrt(l);
      dVal = str(l);
      noNum = true;
    } else {
      r = sqrt(r);
      dVal = str(r);
      noNum = true;
    }
  } else if (val.equals("sin")) {
    if (left) {
      l = sin(radians(l));
      dVal = str(l);
      noNum = true;
    } else {
      r = sin(radians(r));
      dVal = str(r);
      noNum = true;
    }
  } else if (val.equals("cos")) {
    if (left) {
      l = cos(radians(l));
      dVal = str(l);
      noNum = true;
    } else {
      r = cos(radians(r));
      dVal = str(r);
      noNum = true;
    }
  } else if (val.equals(".") && !dVal.contains(".")) {
    dVal += (val);
  } else if (val.equals("=")) {
    performCalc();
    op = "";
  }
  return val;
}

//perform operator calculations
public void performCalc() {
  if (op.equals("+")) {
    result = l + r;
  } else if (op.equals("-")) {
    result = l - r;
  } else if (op.equals("x")) {
    result = l * r;
  } else if (op.equals("/")) {
    result = l / r;
  }
  l = result;
  r = 0;
  dVal = str(result);
  left = true;
}
//consider changing number button color
class Button {
  // Member variables
  int x, y, w, h;
  int c1, c2, c3, c4;
  String val;
  boolean hover, isNumber;

  // Constructor
  Button(int tempX, int tempY, int tempW, int tempH, String tempVal, boolean isNumber, int tempc1, int tempc2) {
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    c1 = tempc1;
    c2 = tempc2;
    //c3 = #00CBBC; #00B1CE
    //c4 = #03A089; #028BA2
    val = tempVal;
    hover = false;
    this.isNumber = isNumber;
  }

  // Display Method
  public void display() {
    if (hover) {
      fill (c2);
    } else {
      fill (c1);
    }

  rect (x, y, w, h, 7);

  strokeWeight (4);
  stroke (0, 100);
  line (x+2, y+h-2, x+w-2, y+h-2);
  line (x+w-2, y+h-2, x+w-2, y+2);

  stroke (255, 100);
  line (x+2, y+h-2, x+2, y+2);
  line (x+2, y+2, x+w-2, y+2);

  strokeWeight (1);

  fill (0);
  textAlign (CENTER);
  textSize (14);
  text (val, x+w/2-1, y+h/2+3);
}

// Hover Method
public void hover() {
  hover = (mouseX>x && mouseX<x+w && mouseY>y && mouseY<y+h);
}
}
  public void settings() {  size (420, 560); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
